#include <gl/glut.h>

void myDisplay()

{
	glClear(GL_COLOR_BUFFER_BIT);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glColor4f(1, 0, 0, 0.5);
	glutSolidSphere(0.3, 20, 16);

	glTranslatef(0.5, 0.5, 0.0);

	glColor4f(0, 1, 0, 0.6);
	glRectf(-0.5, -0.5, 1, 1);

	glutSwapBuffers();

}

int main(int argc, char* argv[])

{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE);
	glutInitWindowPosition(200, 200);
	glutInitWindowSize(500, 500);
	glutCreateWindow("My Scene");
	glutDisplayFunc(&myDisplay);
	glutMainLoop();
	return 0;
}