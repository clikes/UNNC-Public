#include "Planet.h"


//
//Planet::Planet()
//{
//}
//
//
//Planet::~Planet()
//{
//}
