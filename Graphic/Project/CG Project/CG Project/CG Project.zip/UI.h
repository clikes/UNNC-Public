#pragma once
class UI
{
public:
	UI();
	~UI();
};

