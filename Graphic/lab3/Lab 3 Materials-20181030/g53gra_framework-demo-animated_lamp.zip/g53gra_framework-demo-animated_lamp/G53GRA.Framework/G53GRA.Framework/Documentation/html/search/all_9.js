var searchData=
[
  ['orientation',['orientation',['../class_displayable_object.html#a0101b77de7909105221c772e8b969d48',1,'DisplayableObject::orientation(float rx, float ry, float rz)'],['../class_displayable_object.html#ac2bf3fd3c6e8c902e250c9df4b06dc1b',1,'DisplayableObject::orientation()']]]
];
