#ifndef __Animation__
#define __Animation__

class Animation
{

public:
	virtual void update(float dT) = 0;
};

#endif