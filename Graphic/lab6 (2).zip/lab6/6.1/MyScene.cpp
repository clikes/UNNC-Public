#include "MyScene.h"

void setup()
{
	int width = 600;
	int height = 400;
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE);
	glutInitWindowSize(width, height);
	glutCreateWindow("My scene");
	Tree* tree;
	tree = new Tree();
	tree->setReplaceString('f', "ff-[-& f + ff + < +f] + [+>f--f&-f]");
	tree->setInitString("F");
	tree->setNumIter(5);
	tree->setReplaceString('F', "^fG>>>G>>>>>G");
	tree->addReplaceString('G', "[^^f>>>>>>F]");
	objects["tree"] = tree;
	reshape(width, height);
}

void setGlobalLight()
{
	float ambient[] = { 0.2f, 0.2f, 0.2f, 1.f };
	float diffuse[] = { 0.5f, 0.5f, 0.5f, 1.f };
	float specular[] = { 1.f, 1.f, 1.f, 1.f };
	float position[] = { 1.f, 0.5f, 1.f, 0.f };

	glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
	glLightfv(GL_LIGHT0, GL_POSITION, position);

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
}


void draw()
{

	glClearColor(1.f, 1.f, 1.f, 1.f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glEnable(GL_NORMALIZE);

	glTranslatef(0.f, -1.f, -10.f);
	glScaled(3.f, 3.f, 3.f);
	glColor3f(0.f, 0.f, 0.f);


	for (map <string, DisplayableObject*>::iterator itr = objects.begin(); itr != objects.end(); ++itr)
	{
		
		itr->second->display();
	}

	checkGLError();
	glutSwapBuffers();
}




void reshape(int _width, int _height)
{
	int width = _width;
	int height = _height;

	GLdouble aspect = static_cast<GLdouble>(width) / static_cast<GLdouble>(height);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0, aspect, 1, 150);
	glViewport(0, 0, width, height);
	glMatrixMode(GL_MODELVIEW);

}



int main(int argc, char **argv)
{
	glutInit(&argc, argv);
	setup();
	setGlobalLight();
	glutDisplayFunc(draw);
	checkGLError();
	glutReshapeFunc(reshape);
	glutMainLoop();
	return 0;
}

void checkGLError()
{
	int e = 0;
	GLenum error = glGetError();
	while (GL_NO_ERROR != error)
	{
		e++;
		printf("GL Error %i: %s\n", e, gluErrorString(error));
		error = glGetError();
	}

}
